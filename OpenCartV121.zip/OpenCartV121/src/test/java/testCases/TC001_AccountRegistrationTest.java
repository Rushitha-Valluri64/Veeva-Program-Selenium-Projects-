package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.AccountRegistrationPage;
import pageObjects.HomePage;
import testBase.BaseClass;

public class TC001_AccountRegistrationTest extends BaseClass{
		
	@Test(groups={"Regression","Master"})
	public void test_account_registration()
	{
		
		logger.info("****Starting TC001_AccountRegistrationTest****");		
		try 
		{
			HomePage hp=new HomePage(driver);
			hp.clickMyAccount();
			logger.info("Clicked on MyAccount link");
			
			hp.clickRegister();
			logger.info("Clicked on Register link");
			
			AccountRegistrationPage arp=new AccountRegistrationPage(driver);
			
			logger.info("Providing customer details...");
			arp.setFirstName(randomString().toUpperCase());
			arp.setLastName(randomString().toUpperCase());
			arp.setEmail(randomString()+"@gmail.com");
			arp.setTelephone(randomNumber());
			
			String pass=randomAlphaNumber();
			
			arp.setPassword(pass);
			arp.setConfirmPassword(pass);
			arp.setAgree();
			arp.setRegister();
			
			logger.info("Validating expected message..");
			
			String confMsg=arp.getConfirmMsg();
			if(confMsg.equals("Your Account Has Been Created!"))
			{
				Assert.assertTrue(true);
			}
			else
			{
				logger.error("Test failed...");
				logger.debug("Debug logs...");
				Assert.assertTrue(false);
			}
			
		}
		catch(Exception e)
		{
			Assert.fail();
		}
		
		logger.info("****Finishing TC001_AccountRegistrationTest****");	
		
	}

	
}
