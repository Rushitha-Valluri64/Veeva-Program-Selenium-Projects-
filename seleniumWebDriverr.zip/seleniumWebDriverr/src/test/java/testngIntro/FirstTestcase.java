package testngIntro;

import org.testng.annotations.Test;

/* 
 * 1. open app
 * 2. login
 * 3. logout
 */


public class FirstTestcase {
	
	@Test(priority=-1)
	void logout()
	{
		System.out.println("Logging out of the application...");
	}
	
	@Test(priority=-2)
	void openapp()
	{
		System.out.println("Opening application...");
	}
	
	@Test(priority=0)
	void login()
	{
		System.out.println("Logging into application...");
	}

	
}
