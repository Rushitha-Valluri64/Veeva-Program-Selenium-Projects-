package webDriverMethods;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class ConditionalNMethods {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.nopcommerce.com/register");
		driver.manage().window().maximize();
		
		//isDisplayed
		WebElement logo=driver.findElement(By.xpath("//img[@alt='nopCommerce demo store']"));
		System.out.println("Display status of logo: "+logo.isDisplayed());
	
		boolean logostatus=driver.findElement(By.xpath("//img[@alt='nopCommerce demo store']")).isDisplayed();
		System.out.println("Display status of logo: "+logostatus);
		
		//isEnabled
		boolean status=driver.findElement(By.xpath("//input[@id='FirstName']")).isEnabled();
		System.out.println("Enable status of id: "+status);
		if(status==true)
		{
			driver.findElement(By.xpath("//input[@id='FirstName']")).sendKeys("Rishitha");
		}
		
		//isSelected
		WebElement m_radio= driver.findElement(By.xpath("//input[@id='gender-male']"));
		WebElement fm_radio= driver.findElement(By.xpath("//input[@id='gender-female']"));
		System.out.println("Before selecting-----");
		System.out.println("Male button status: "+m_radio.isSelected());
		System.out.println("Female button status: "+fm_radio.isSelected());
		
		System.out.println("After selecting-----");
		fm_radio.click();
		System.out.println("Male button status: "+m_radio.isSelected());
		System.out.println("Female button status: "+fm_radio.isSelected());
		
		System.out.println("After selecting-----");
		m_radio.click();
		System.out.println("Male button status: "+m_radio.isSelected());
		System.out.println("Female button status: "+fm_radio.isSelected());
		
		boolean newsstatus=driver.findElement(By.xpath("//label[normalize-space()='Newsletter']")).isSelected();
		System.out.println("News letter button status: "+newsstatus);
	}

}
