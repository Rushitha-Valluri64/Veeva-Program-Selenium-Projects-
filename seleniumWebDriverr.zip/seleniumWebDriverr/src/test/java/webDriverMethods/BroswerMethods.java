package webDriverMethods;

import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BroswerMethods {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		
		//get url
		driver.get("https://tutorialsninja.com/demo");
		Thread.sleep(5000);

		driver.findElement(By.linkText("Tablets")).click();
		Thread.sleep(5000);
		//driver.close();
		driver.quit();
		
	}

}
