package webDriverMethods;

import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetMethods {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		
		//get url
		driver.get("https://tutorialsninja.com/demo");
		Thread.sleep(5000);

		//getTitle
		String title=driver.getTitle();
		System.out.println(title);
		
		//getCurrentUrl
		System.out.println("Current url is: "+driver.getCurrentUrl());
		
		////getPageSource
		System.out.println("Page source: "+driver.getPageSource());
		
		//getWindowHandle
		String windowID=driver.getWindowHandle();
		System.out.println("Window ID: "+windowID);
		
		//getWindowHandles
		driver.findElement(By.linkText("Tablets")).click();
		Set<String>handles=driver.getWindowHandles();
		System.out.println("Handles are: "+handles);
		
	}

}
