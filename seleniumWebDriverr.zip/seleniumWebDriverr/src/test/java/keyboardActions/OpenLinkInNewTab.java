package keyboardActions;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class OpenLinkInNewTab {
	public static void main(String args[]) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		
		WebElement element=driver.findElement(By.xpath("//a[normalize-space()='OrangeHRM, Inc']"));
		
		Actions act=new Actions(driver);
		
		//control+registration link
		act.keyDown(Keys.CONTROL).click(element).keyUp(Keys.CONTROL).perform();
		
		//switch to registration page
		String parentWindow=driver.getWindowHandle();
		List<String>id=new ArrayList<>(driver.getWindowHandles());
		for (String win : id) {
            if (!win.equals(parentWindow)) {
                driver.switchTo().window(win);
                break;
            }
        }
		
		driver.findElement(By.xpath("//input[@id='Form_submitForm_EmailHomePage']")).sendKeys("vallurigowthami60");
		
		//switch to home page
		driver.switchTo().window(id.get(0));
		driver.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys("Admin");
		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("admin123");
		WebElement login=driver.findElement(By.xpath("//button[normalize-space()='Login']"));
		act.keyDown(Keys.CONTROL).click(login).keyUp(Keys.CONTROL).perform();
		
	}
}
