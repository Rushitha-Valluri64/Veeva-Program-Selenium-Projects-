package keyboardActions;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SliderDemo {

	public static void main(String args[]) {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.jqueryscript.net/demo/Price-Range-Slider-jQuery-UI/");
		driver.manage().window().maximize();
		
		//capture the location of the element
		WebElement minslider=driver.findElement(By.xpath("//div[@class='price-range-block']//span[1]"));
		System.out.println("Default Location of minimum slider is: "+minslider.getLocation());
		//System.out.println("Location X axis of minimum slider is: "+minslider.getLocation().getX());
		//System.out.println("Location Y axis of minimum slider is: "+minslider.getLocation().getY());
		
		Actions act=new Actions(driver);
		act.dragAndDropBy(minslider, 100, 0).perform();

		System.out.println("Location of minimum slider now is: "+minslider.getLocation());
		
		//for(int i=1;i<=10;i++)
		//{
			//act.dragAndDropBy(minslider, i+20, 0).perform();
		//}
		
		System.out.println();
		WebElement maxslider=driver.findElement(By.xpath("//div[@class='price-range-block']//span[2]"));
		System.out.println("Default Location of maximum slider is: "+maxslider.getLocation());
		act.dragAndDropBy(maxslider, -100, 0).perform();
		System.out.println("Location of maximum slider now is: "+maxslider.getLocation());
		
		
		/*driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		Actions act=new Actions(driver);
		WebElement minslider=driver.findElement(By.xpath("//div[@id='HTML7']//span[1]"));
		System.out.println("Location of minimum slider is: "+minslider.getLocation());
		WebElement maxslider=driver.findElement(By.xpath("//div[@id='HTML7']//span[2]"));
		System.out.println("Location of maximum slider is: "+maxslider.getLocation());
		act.dragAndDropBy(minslider, 80, 0).perform();
		System.out.println("Location of minimum slider now is: "+minslider.getLocation());
		act.dragAndDropBy(maxslider, -30, 0).perform();
		System.out.println("Location of maximum slider now is: "+maxslider.getLocation());
		*/
	}
}
