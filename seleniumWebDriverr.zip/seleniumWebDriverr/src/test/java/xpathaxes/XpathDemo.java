package xpathaxes;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class XpathDemo {
	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://money.rediff.com/gainers/daily/groupa");
		driver.manage().window().maximize();
		
		//self-selects the current node
		String text=driver.findElement(By.xpath("//a[contains(text(),'CHL')]/self::a")).getText();
		System.out.println("Self: "+text);
		
		//parent-selects the parent of current node (Exactly one)
		text=driver.findElement(By.xpath("//a[contains(text(),'CHL')]/parent::td")).getText();
		System.out.println("Parent: "+text);
		
		//child-selects the children of current node (One or more)
		List<WebElement> childs=driver.findElements(By.xpath("//a[contains(text(),'CHL')]/ancestor::tr/child::td"));
		System.out.println("No:of children:"+childs.size());
		
		
		//ancestor-selects the all ancestors of current node (parent, grandparent etc..)
		text=driver.findElement(By.xpath("//a[contains(text(),'CHL')]/ancestor::tr")).getText();
		System.out.println("Ancestor: "+text);
		
		//descendant-selects the all descendants of current node (child, grandchildren etc..)
		List<WebElement> descendants = driver.findElements(By.xpath("//a[contains(text(),'CHL')]/ancestor::tr/descendant::*"));
		System.out.println("No:of descendant nodes:"+descendants.size());
		
		//following-selects everything after the closing tag of the current node
		List<WebElement> followingnodes=driver.findElements(By.xpath("//a[contains(text(),'CHL')]/ancestor::tr/following::tr"));
		System.out.println("No:of following nodes:"+followingnodes.size());
		
		//preceding-selects everything before the opening tag of the current node
		List<WebElement> preceedingnodes=driver.findElements(By.xpath("//a[contains(text(),'CHL')]/ancestor::tr/preceding::tr"));
		System.out.println("No:of preeceding nodes:"+preceedingnodes.size());
		
		
		//following-siblings -selects siblings before the opening tag of the current node
		List<WebElement> followingsiblingsingnodes=driver.findElements(By.xpath("//a[contains(text(),'CHL')]/ancestor::tr/following-sibling::tr"));
		System.out.println("No:of following sibling nodes:"+followingsiblingsingnodes.size());
				
		//preceding-siblings -selects siblings before the opening tag of the current node
		List<WebElement> preceedingsiblingsnodes=driver.findElements(By.xpath("//a[contains(text(),'CHL')]/ancestor::tr/preceding-sibling::tr"));
		System.out.println("No:of preeceding siblings nodes:"+preceedingsiblingsnodes.size());
		
		driver.quit();
	}

}
