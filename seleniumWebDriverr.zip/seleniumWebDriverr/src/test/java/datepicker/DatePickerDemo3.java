package datepicker;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DatePickerDemo3 {
	public static void main(String args[]) {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//input[@id='name']")).sendKeys("Rishitha");
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("vallurigowthami60");
		driver.findElement(By.xpath("//input[@id='phone']")).sendKeys("9392582344");
		driver.findElement(By.xpath("//textarea[@id='textarea']")).sendKeys("Krishnayapalem");
		driver.findElement(By.xpath("//input[@id='female']")).click();
		driver.findElement(By.xpath("//label[normalize-space()='Monday']")).click();
		driver.findElement(By.xpath("//label[normalize-space()='Thursday']")).click();
		driver.findElement(By.xpath("//label[normalize-space()='Saturday']")).click();
		WebElement drp=driver.findElement(By.xpath("//select[@id='country']"));
		Select country=new Select(drp);
		country.selectByVisibleText("India");
		
		driver.findElement(By.xpath("//input[@id='datepicker']")).sendKeys("25/09/2026");
		
		driver.findElement(By.xpath("(//input[@id='txtDate'])[1]")).click();
		WebElement drpmonth=driver.findElement(By.xpath("//select[@aria-label='Select month']"));
		Select mon=new Select(drpmonth);
		mon.selectByVisibleText("Sep");
		
		WebElement drpyear=driver.findElement(By.xpath("//select[@aria-label='Select year']"));
		Select yea=new Select(drpyear);
		yea.selectByVisibleText("2024");
		
		String date="25";
		
		
		List<WebElement> cdate=driver.findElements(By.xpath("//div[@id='ui-datepicker-div']//tbody//tr//td//a"));
		
		for(WebElement d:cdate)
		{
			
			if(d.getText().equals(date))
			{
				d.click();
				break;
			}
		}
	}

}
