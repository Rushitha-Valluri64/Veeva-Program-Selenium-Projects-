package dropdowns;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectDropdown {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		WebElement country=driver.findElement(By.xpath("//select[@id='country']"));
		Select drp=new Select(country);
		
		//select option from the dropdown
		
		//selection using visible text
		//drp.selectByVisibleText("India");
		
		//selection using value
		//drp.selectByValue("india");
		//drp.selectByValue("brazil");
		
		//selection using index
		//drp.selectByIndex(5);
		//drp.selectByIndex(20); Gives error:cannot locate element with index 20
		
		//capture the options from dropdown
		List<WebElement> list=drp.getOptions();
		System.out.println("No:of options are: "+list.size());
		
		//print the all options
		/*for(int i=0;i<list.size();i++)
		{
			System.out.println(list.get(i).getText());
		}*/
		
		for(WebElement element:drp.getOptions())
		{
			System.out.println(element.getText());
		}
	}

}
