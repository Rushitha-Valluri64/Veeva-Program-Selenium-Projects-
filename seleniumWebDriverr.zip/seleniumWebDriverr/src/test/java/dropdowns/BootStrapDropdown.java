package dropdowns;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BootStrapDropdown {
	public static void main(String args[])
	{
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.htmlelements.com/demos/dropdownlist/multiple-selection-mode/");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//smart-drop-down-list//span[contains(@class,'smart-action-button')]")).click();
		
		//select single option
		driver.findElement(By.xpath("//span[normalize-space()='Cortado']")).click();
		
	
	}

}
