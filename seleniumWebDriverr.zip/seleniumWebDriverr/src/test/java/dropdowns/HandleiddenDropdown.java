package dropdowns;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleiddenDropdown {
	public static void main(String args[]) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		
		//Login steps
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
		System.out.println("Login done!!");
		
		//choose PIM
		driver.findElement(By.xpath("//span[normalize-space()='PIM']")).click();
		System.out.println("PIM selection done!!");
		
		//clicking on dropdown
		driver.findElement(By.xpath("//label[normalize-space()='Job Title']/following::div[contains(@class,'oxd-select-text')][1]")).click();
		System.out.println("Clicked on dropdown!!");
		Thread.sleep(5000);
		
		//select single option
		//driver.findElement(By.xpath("//span[normalize-space()='Financial Analyst']")).click();
		//System.out.println("Option selected!!");
		
		//count number of options
		List<WebElement> list=driver.findElements(By.xpath("//div[@role='listbox']//span"));
		System.out.println("Number of options: "+list.size());
		
		//printing options
		for(WebElement op:list)
		{
			System.out.println(op.getText());
		}
	}
	
	

}
