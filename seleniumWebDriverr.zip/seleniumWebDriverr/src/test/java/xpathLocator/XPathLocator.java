package xpathLocator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class XPathLocator {
	public static void main(String ars[]) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://tutorialsninja.com/demo");
		driver.manage().window().maximize();
		
		//xpath with single attribute
		//driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys("T-Shirts");
		
		//xpath with multiple attributes
		//driver.findElement(By.xpath("//input[@name='search'][@placeholder='Search']")).sendKeys("T-Shirts");
		
		//xpath with 'and' 'or' operators
		//driver.findElement(By.xpath("//input[@name='search' and @placeholder='Search']")).sendKeys("T-Shirts");
		//driver.findElement(By.xpath("//input[@name='search' or @placeholder='Search']")).sendKeys("T-Shirts");
		
		//xapth with text() - inner text
		//driver.findElement(By.xpath("//*[text()='iPhone']")).click();
		
		//boolean displaystatus=driver.findElement(By.xpath("//h3[text()='Featured']")).isDisplayed();
		//System.out.println(displaystatus);
		
		//String value=driver.findElement(By.xpath("//h3[text()='Featured']")).getText();
		//System.out.println(value);
		
		//xpath with contains()
		//driver.findElement(By.xpath("//input[contains(@placeholder,'Sea')]")).sendKeys("Tshirts");
		
		//xpath with start-with()
		//driver.findElement(By.xpath("//input[starts-with(@placeholder,'Sea')]")).sendKeys("Tshirts");
		
		// chained xpath
		//boolean status=driver.findElement(By.xpath("//div[@id='logo']/a/img")).isDisplayed();
		//System.out.println(status);
	}

}
