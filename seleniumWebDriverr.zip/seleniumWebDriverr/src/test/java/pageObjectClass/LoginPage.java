package pageObjectClass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	
	WebDriver driver;
	
	//constructors
	
	LoginPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	
	//locators
	
	By username=By.xpath("//input[@placeholder='Username']");
	By password=By.xpath("//input[@placeholder='Password']");
	By login=By.xpath("//button[normalize-space()='Login']");

	
	//action methods
	
	public void setUserName(String user)
	{
		driver.findElement(username).sendKeys(user);
	}
	
	public void setPassword(String pwd)
	{
		driver.findElement(password).sendKeys(pwd);
	}
	
	public void clickLogin()
	{
		driver.findElement(login).click();
	}

}
