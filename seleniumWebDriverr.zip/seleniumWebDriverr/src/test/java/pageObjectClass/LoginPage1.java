package pageObjectClass;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPage1 {
	
	WebDriver driver;
	
	//constructors
	
	LoginPage1(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	
	//locators
	
	@FindBy(xpath="//input[@placeholder='Username']") 
	
	//@FindBy(how=How.XPATH, using ="//input[@placeholder='Username']")
	WebElement username;
	
	@FindBy(xpath="//input[@placeholder='Password']") 
	WebElement password;
	
	@FindBy(xpath="//button[normalize-space()='Login']") 
	WebElement login;
	
	@FindBy(tagName="a")
	List<WebElement> links;

	
	//action methods
	
	public void setUserName(String user)
	{
		username.sendKeys(user);
	}
	
	public void setPassword(String pwd)
	{
		password.sendKeys(pwd);
	}
	
	public void clickLogin()
	{
		login.click();
	}

}
