package dependencyMethods;

import org.testng.annotations.Test;

public class SignUpTest {

	@Test(priority=1,groups={"regression"})
	void signupByEmail()
	{
		System.out.println("This is signup by email...");
	}
	
	@Test(priority=2,groups={"regression"})
	void signupByPassword()
	{
		System.out.println("This is signup by password...");
	}
	
	@Test(priority=3,groups={"regression"})
	void signupByFacebook()
	{
		System.out.println("This is signup by facebook...");
	}
}
