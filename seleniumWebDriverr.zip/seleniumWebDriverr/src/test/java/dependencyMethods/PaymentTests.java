package dependencyMethods;

import org.testng.annotations.Test;

public class PaymentTests {
	
	@Test(priority=1,groups={"sanity","regression","functional"})
	void paymentRupees()
	{
		System.out.println("This is payment done in rupees...");
	}
	
	@Test(priority=2,groups={"sanity","regression","functional"})
	void paymentDollars()
	{
		System.out.println("This is payment done in dollars...");
	}
	
	@Test(priority=3,groups={"sanity","regression","functional"})
	void paymentBits()
	{
		System.out.println("This is payment done in bits...");
	}

}
