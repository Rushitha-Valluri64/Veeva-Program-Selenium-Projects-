package dataDrivenTesting;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.Collection;
import java.util.Properties;
import java.util.Set;

public class ReadingPropertiesFile {
	
	public static void main(String args[]) throws IOException {
		
		//location of file
		FileInputStream file=new FileInputStream(System.getProperty("user.dir")+"\\testdata\\config.properties");
		
		//loading properties file
		Properties properties=new Properties();
		properties.load(file);
		
		//reading data from properties file
		String url=properties.getProperty("appurl");
		String email=properties.getProperty("email");
		String password=properties.getProperty("password");
		String orderid=properties.getProperty("orderid");
		String customerid=properties.getProperty("customerid");
		
		//printing properties data
		System.out.println(url);
		System.out.println(email);
		System.out.println(password);
		System.out.println(orderid);
		System.out.println(customerid);
		
		//reading only keys from properties file
		Set<Object> keys=properties.keySet();
		System.out.println("Keys are: "+keys);
		
		//reading only values from properties file
		Collection<Object> values=properties.values();
		System.out.println("Values are: "+values);
	}

}
