package dataDrivenTesting;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadingDataFromExcel {
	public static void main(String args[]) throws IOException {
		
		//get the excel file
		FileInputStream file=new FileInputStream(System.getProperty("user.dir")+"\\testdata\\TestData.xlsx");
		
		//extract workbook from file
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		
		//extract sheet from workbook
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		
		//returns total num of rows in a sheet
		int rows=sheet.getLastRowNum();
		
		//extract rows from sheet
		int cells=sheet.getRow(1).getLastCellNum();
		
		System.out.println("Number of rows: "+rows);
		System.out.println("Number of cells: "+cells);
		
		for(int r=0;r<=rows;r++)
		{
			XSSFRow crow=sheet.getRow(r);
			for(int c=0;c<cells;c++)
			{
				XSSFCell cell=crow.getCell(c);
				System.out.print(cell.toString()+" | ");
			}
			System.out.println();
		}
		workbook.close();
		file.close();
	}
}
