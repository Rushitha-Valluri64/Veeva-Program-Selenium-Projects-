package testngAnnotation;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class HardVsSoftAssertions {

	
	@Test
	/*void test_hardassertions()
	{
		System.out.println("testng...");
		System.out.println("testng...");
		
		Assert.assertTrue(1==3); //hard assertion
		
		System.out.println("testng...");
		System.out.println("testng...");
	}
	*/
	
	//@Test
	void test_softassertions()
	{
		System.out.println("testng...");
		System.out.println("testng...");
		
		SoftAssert sa=new SoftAssert();
		
		sa.assertTrue(1==3); //soft assertion
		
		System.out.println("testng...");
		System.out.println("testng...");
		
		sa.assertAll();
	}
}
