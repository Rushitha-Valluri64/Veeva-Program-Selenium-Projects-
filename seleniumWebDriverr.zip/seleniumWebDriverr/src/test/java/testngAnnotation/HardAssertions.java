package testngAnnotation;

import org.testng.Assert;
import org.testng.annotations.Test;

public class HardAssertions {
	
	@Test
	void test()
	{
		//Assert.assertEquals("xyz", "xyz");
		//Assert.assertEquals(123, 123);
		//Assert.assertEquals("123", 123);
		//Assert.assertNotEquals("xyz", "xyz");
		//Assert.assertNotEquals("xyz", "abc");
		//Assert.assertTrue(true);
		//Assert.assertFalse(false);
		//Assert.assertTrue(1==2);
		//Assert.assertFalse(1==2);
	}

}
