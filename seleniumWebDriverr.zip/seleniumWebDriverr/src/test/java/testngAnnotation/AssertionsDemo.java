package testngAnnotation;

import org.testng.Assert;
import org.testng.annotations.Test;

public class AssertionsDemo {
	
	@Test
	void testTitle() 
	{
		String exp="Opencart";
		String act="Openshop";
		
		if(exp.equals(act))
		{
			System.out.println("Passsed!!");
			Assert.assertTrue(true);
		}
		else
		{
			System.out.println("Failed!!");
			Assert.assertTrue(false);
		}
		
		
		//Assert.assertEquals(exp, act);
	}

}
