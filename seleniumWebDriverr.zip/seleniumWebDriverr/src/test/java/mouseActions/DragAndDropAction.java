package mouseActions;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DragAndDropAction {
	public static void main(String args[]) {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		/*driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		Actions act=new Actions(driver);
		
		WebElement src=driver.findElement(By.xpath("//p[normalize-space()='Drag me to my target']"));
		WebElement target=driver.findElement(By.xpath("//div[@id='droppable']"));
		
		act.dragAndDrop(src, target).perform();
		
		if(target.getText().equals("Dropped!"))
		{
			System.out.println("Dropped successfully!!");
		}
		else
		{
			System.out.println("Error occured!!");
		}
		*/
		
		driver.get("https://demo.guru99.com/test/drag_drop.html");
		driver.manage().window().maximize();
		
		WebElement src1=driver.findElement(By.xpath("//a[normalize-space()='BANK']"));	
		WebElement target1=driver.findElement(By.xpath("//ol[@id='bank']//li[@class='placeholder']"));
		
		Actions act=new Actions(driver);
		act.dragAndDrop(src1, target1).perform();
		
		WebElement src2=driver.findElement(By.xpath("//section[@id='g-container-main']//li[2]//a[1]"));	
		WebElement target2=driver.findElement(By.xpath("//ol[@id='amt7']//li[@class='placeholder']"));
		
		act.dragAndDrop(src2, target2).perform();
		
		WebElement src3=driver.findElement(By.xpath("//a[normalize-space()='SALES']"));	
		WebElement target3=driver.findElement(By.xpath("//ol[@id='loan']//li[@class='placeholder']"));
		
		act.dragAndDrop(src3, target3).perform();
		
		WebElement src4=driver.findElement(By.xpath("//section[@id='g-container-main']//li[4]//a[1]"));	
		WebElement target4=driver.findElement(By.xpath("//ol[@id='amt8']//li[@class='placeholder']"));
				
		act.dragAndDrop(src4, target4).perform();
	
	}

}
