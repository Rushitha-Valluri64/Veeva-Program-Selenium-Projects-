package mouseActions;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseHoverAction {
	
	public static void main(String args[]) {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://tutorialsninja.com/demo/");
		driver.manage().window().maximize();
		
		//WebElement element1=driver.findElement(By.xpath("//a[normalize-space()='Desktops']"));
		//WebElement element2=driver.findElement(By.xpath("//a[normalize-space()='Mac (1)']"));
		
		//Actions act=new Actions(driver);
		//act.moveToElement(element1).build().perform();
		
		//mouse hover action
		//act.moveToElement(element2).click().build().perform();
		
		WebElement components=driver.findElement(By.xpath("//a[normalize-space()='Components']"));
		WebElement printers=driver.findElement(By.xpath("//a[normalize-space()='Printers (0)']"));
		
		Actions act1=new Actions(driver);
		act1.moveToElement(components).moveToElement(printers).click().perform();
		
		
	}
}
