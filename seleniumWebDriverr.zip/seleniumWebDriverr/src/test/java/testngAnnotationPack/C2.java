package testngAnnotationPack;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class C2 {

	
	@Test
	void xyz()
	{
		System.out.println("This is xyz from class 2...");
	}
	
	@AfterTest
	void at()
	{
		System.out.println("This is after test method...");
	}
}
