package testngAnnotationPack;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class C3 {

	@Test
	void pqr()
	{
		System.out.println("This is pqr form c3...");
	}
	
	@BeforeSuite
	void s1()
	{
		System.out.println("This is Before suite from c3...");
	}
	
	@AfterSuite
	void s2()
	{
		System.out.println("This is After suite from c3...");
	}
}
