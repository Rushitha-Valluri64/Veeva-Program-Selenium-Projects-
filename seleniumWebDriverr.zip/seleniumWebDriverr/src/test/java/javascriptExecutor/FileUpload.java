package javascriptExecutor;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FileUpload {
public static void main(String args[]) {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://davidwalsh.name/demo/multiple-file-upload.php");
		driver.manage().window().maximize();
		
		//single file upload
		/*driver.findElement(By.xpath("//input[@id='filesToUpload']")).sendKeys("C:\\Users\\PC\\Downloads\\22A81A0564_RESUME.pdf");
		
		if(driver.findElement(By.xpath("//ul[@id='fileList']//li")).getText().equals("22A81A0564_RESUME.pdf"))
		{
			System.out.println("File uploaded successfully!!");
		}
		else
		{
			System.out.println("File upload failed!!");
		}
		*/
		
		//multiple files upload
		String file1="C:\\Users\\PC\\Downloads\\22A81A0564_RESUME.pdf";
		String file2="C:\\Users\\PC\\Downloads\\Mrudula_V.pdf";
		String file3="C:\\Users\\PC\\Downloads\\Resume_46.pdf";
		driver.findElement(By.xpath("//input[@id='filesToUpload']")).sendKeys(file1+"\n"+file2+"\n"+file3);
		
		int files=driver.findElements(By.xpath("//ul[@id='fileList']//li")).size();
		System.out.println("No:of files uploaded: "+files);
		
		if(files==3)
		{
			System.out.println("Files uploaded successfully!!");
		}
		else
		{
			System.out.println("Something wrong!!");
		}
	}

}
