package javascriptExecutor;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScriptExecutorDemo {
	public static void main(String args[]) {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		WebElement input=driver.findElement(By.xpath("//input[@id='name']"));
		
		//WebDriver driver=new ChromeDriver();
		JavascriptExecutor js=(JavascriptExecutor)driver;
		
		//ChromeDriver driver=new ChromeDriver();
		//JavascriptExecutor js=driver;
		
		//passing text into input box
		js.executeScript("arguments[0].setAttribute('value','Rishitha')",input);
		
		//clicking radio button
		WebElement radio=driver.findElement(By.xpath("//input[@id='female']"));
		js.executeScript("arguments[0].click()",radio);
		
		//clicking check box
		WebElement checkbox=driver.findElement(By.xpath("//input[@id='friday']"));
		js.executeScript("arguments[0].click()",checkbox);
		
	}

}
