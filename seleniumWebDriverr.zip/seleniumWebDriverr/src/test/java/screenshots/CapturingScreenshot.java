package screenshots;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CapturingScreenshot {
	public static void main(String args[]) {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://demo.nopcommerce.com/");
		driver.manage().window().maximize();
		
		//full page screenshot
		/*TakesScreenshot ts=(TakesScreenshot)driver;
		File src=ts.getScreenshotAs(OutputType.FILE);
		File target=new File(System.getProperty("user.dir")+"\\screenshots\\fullpage.png");
		src.renameTo(target);
		*/
		
		// capture particular place screenshot
		/*WebElement featurebox=driver.findElement(By.xpath("//section[@class='product-grid home-page-product-grid']"));
		File src=featurebox.getScreenshotAs(OutputType.FILE);
		File target=new File(System.getProperty("user.dir")+"\\screenshots\\featureBox.png");
		src.renameTo(target);
		*/
		
		//capture particular webElement screenshot
		//h2[normalize-space()='Welcome to our store']
		
		WebElement element=driver.findElement(By.xpath("//h2[normalize-space()='Welcome to our store']"));
		File src=element.getScreenshotAs(OutputType.FILE);
		File target=new File(System.getProperty("user.dir")+"\\screenshots\\element.png");
		src.renameTo(target);
		
	}
}
