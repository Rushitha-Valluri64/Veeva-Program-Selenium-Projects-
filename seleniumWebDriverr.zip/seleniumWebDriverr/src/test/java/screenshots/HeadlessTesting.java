package screenshots;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HeadlessTesting {

	public static void main(String args[]) {
		
		ChromeOptions options=new ChromeOptions();
		
		//sets for headless mode testing
		options.addArguments("--headless=new");
		
		WebDriver driver=new ChromeDriver(options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://tutorialsninja.com/demo/");
		driver.manage().window().maximize();
		
		String title=driver.getTitle();
		if(title.equals("Your Store"))
		{
			System.out.println("Test passed!!");
		}
		else
		{
			System.out.println("Test failed!!");
		}
		
	}
}
