package alerts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleAuthenticatedPop {
	public static void main(String args[]) {
		
		WebDriver driver=new ChromeDriver();
		
		//for alert
		//driver.get("https://the-internet.herokuapp.com/basic_auth");
		
		//for directly injecting credentials into url
		driver.get("http://admin:admin@the-internet.herokuapp.com/basic_auth");
		
	}

}
