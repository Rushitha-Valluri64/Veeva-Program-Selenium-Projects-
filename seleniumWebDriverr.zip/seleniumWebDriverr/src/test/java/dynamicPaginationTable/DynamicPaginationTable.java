package dynamicPaginationTable;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DynamicPaginationTable {
	public static void main(String argss[]) {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		/*driver.findElement(By.xpath("//input[@id='input-username']")).sendKeys("demo");
		driver.findElement(By.xpath("//input[@id='input-password']")).sendKeys("demo");
		driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
		
		driver.findElement(By.xpath("//a[@class='parent collapsed'][normalize-space()='Customers']")).click();
		*/
		
		//driver.findElement(By.xpath("//ul[@id='collapse5']//a[contains(text(),'Customers')]")).click();
		
		
		driver.findElement(By.xpath("//tbody/tr[5]/td[4]/input[1]")).click();
		driver.findElement(By.xpath("//tbody/tr[3]/td[4]/input[1]")).click();
		
		//count total no:of pages
		//WebElement element=driver.findElement(By.xpath("//div[@class='col-sm-6 text-right']"));
		//String str=element.getText();
		//System.out.println("Total no:of pages are: "+Integer.parseInt(str.substring(str.indexOf("(")+1,str.indexOf("Pages")-1)));

		
		//reading data from page
		int rows=driver.findElements(By.xpath("//table[@id='productTable']//tbody//tr")).size();
		System.out.println("Total no:of rows: "+rows);
		
		for(int r=1;r<=rows;r++)
		{
			String id=driver.findElement(By.xpath("//table[@id='productTable']//tbody//tr["+r+"]//td[1]")).getText();
			String name=driver.findElement(By.xpath("//table[@id='productTable']//tbody//tr["+r+"]//td[2]")).getText();
			String price=driver.findElement(By.xpath("//table[@id='productTable']//tbody//tr["+r+"]//td[3]")).getText();
			System.out.println(id+" | "+name+" | "+price);
		}
		
	
	}
}
